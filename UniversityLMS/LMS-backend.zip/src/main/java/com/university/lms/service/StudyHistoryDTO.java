package com.university.lms.service;

import lombok.Data;

@Data
public class StudyHistoryDTO {
    private Long courseId;
    private String courseName;
    private int examsTaken;
    private Double grade;
    private int ectsPoints;
    private boolean passed;

    public StudyHistoryDTO(Long courseId, String courseName, int examsTaken, Double grade, int ectsPoints, boolean passed) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.examsTaken = examsTaken;
        this.grade = grade;
        this.ectsPoints = ectsPoints;
        this.passed = passed;
    }
}