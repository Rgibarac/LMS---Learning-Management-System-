package com.university.lms.service;

import com.university.lms.entity.StudyProgram;
import com.university.lms.repository.StudyProgramRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudyProgramService {

    private static final Logger logger = LoggerFactory.getLogger(StudyProgramService.class);

    @Autowired
    private StudyProgramRepository studyProgramRepository;

    public List<StudyProgram> findAll() {
        logger.info("Fetching all study programs");
        return studyProgramRepository.findAll();
    }

    public Optional<StudyProgram> findById(Long id) {
        logger.info("Fetching study program with id: {}", id);
        return studyProgramRepository.findById(id);
    }
    
    public StudyProgram createStudyProgram(StudyProgram studyProgram) {
        studyProgram.setId(null);
        return studyProgramRepository.save(studyProgram);
    }

    public StudyProgram updateStudyProgram(Long id, StudyProgram studyProgram) {
        studyProgram.setId(id);
        return studyProgramRepository.save(studyProgram);
    }

    public void deleteStudyProgram(Long id) {
        studyProgramRepository.deleteById(id);
    }
    
    public boolean existsById(Long id) {
        return studyProgramRepository.existsById(id);
    }
}