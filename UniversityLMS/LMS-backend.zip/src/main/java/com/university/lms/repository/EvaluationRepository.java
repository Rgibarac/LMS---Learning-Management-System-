package com.university.lms.repository;

import com.university.lms.entity.Course;
import com.university.lms.entity.Evaluation;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface EvaluationRepository extends JpaRepository<Evaluation, Long> {
    List<Evaluation> findByCourseId(Long courseId);
    List<Evaluation> findByCourseIdIn(List<Long> courseIds);
    List<Evaluation> findByType(String type);
}