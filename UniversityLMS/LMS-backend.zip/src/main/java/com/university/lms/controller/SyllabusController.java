package com.university.lms.controller;

import com.university.lms.entity.Syllabus;
import com.university.lms.repository.SyllabusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
@RequestMapping("/api/public")
public class SyllabusController {
    @Autowired
    private SyllabusRepository syllabusRepository;

    @GetMapping("/syllabuses")
    public ResponseEntity<List<Syllabus>> getSyllabuses() {
        return ResponseEntity.ok(syllabusRepository.findAll());
    }
}