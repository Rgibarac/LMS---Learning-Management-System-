DROP ALL OBJECTS;

CREATE TABLE IF NOT EXISTS users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    first_name VARCHAR(255),
    last_name VARCHAR(255),
    index_number VARCHAR(255),
    role VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS study_programs (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    description TEXT
);

CREATE TABLE IF NOT EXISTS courses (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    code VARCHAR(255) NOT NULL,
    ects_points INT,
    study_program_id BIGINT,
    FOREIGN KEY (study_program_id) REFERENCES study_programs(id)
);

CREATE TABLE IF NOT EXISTS syllabuses (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    course_id BIGINT NOT NULL,
    content TEXT NOT NULL,
    academic_year VARCHAR(50) NOT NULL,
    FOREIGN KEY (course_id) REFERENCES courses(id)
);

CREATE TABLE enrollments (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    student_id BIGINT NOT NULL,
    course_id BIGINT,
    study_program_id BIGINT,
    FOREIGN KEY (student_id) REFERENCES users(id),
    FOREIGN KEY (course_id) REFERENCES courses(id),
    FOREIGN KEY (study_program_id) REFERENCES study_programs(id)
);

CREATE TABLE IF NOT EXISTS evaluations (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    course_id BIGINT,
    type VARCHAR(50),
    title VARCHAR(255),
    description TEXT,
    due_date TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(id)
);

CREATE TABLE IF NOT EXISTS evaluation_grades (
    evaluation_id BIGINT,
    user_id BIGINT,
    grade DOUBLE,
    PRIMARY KEY (evaluation_id, user_id),
    FOREIGN KEY (evaluation_id) REFERENCES evaluations(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS exam_registrations (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT,
    evaluation_id BIGINT,
    registration_date TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (evaluation_id) REFERENCES evaluations(id)
);

CREATE TABLE IF NOT EXISTS university (
    id BIGINT PRIMARY KEY,
    name VARCHAR(100),
    description TEXT
);

CREATE TABLE exam_applications (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL,
    course_id BIGINT NOT NULL,
    term VARCHAR(50) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (course_id) REFERENCES courses(id)
);

CREATE TABLE exam_grades (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    exam_application_id BIGINT NOT NULL,
    grade FLOAT NOT NULL,
    number_of_taken_exams INT NOT NULL,
    FOREIGN KEY (exam_application_id) REFERENCES exam_applications(id)
);

-- Sample data
INSERT INTO university (id, name, description) 
VALUES (1, 'University of Example', 'A leading institution for higher education.');

INSERT INTO users (id, username, password, email, first_name, last_name, index_number, role)
VALUES
    (1, 'admin', '$2a$10$z5X8z7y9z1X2Y3Z4X5Y6Z7.8z9A0B1C2D3E4F5G6H7I8J9K0L1M2N', 'admin@example.com', 'Admin', 'User', NULL, 'ADMIN'),
    (3, 'student2', '$2a$10$z5X8z7y9z1X2Y3Z4X5Y6Z7.8z9A0B1C2D3E4F5G6H7I8J9K0L1M2N', 'student2@example.com', 'Jane', 'Doe', '67891', 'STUDENT');

INSERT INTO study_programs (id, name, description)
VALUES
    (1, 'Computer Science B.Sc.', 'Bachelor’s program in Computer Science'),
    (2, 'Mathematics B.Sc.', 'Bachelor’s program in Mathematics');

INSERT INTO courses (id, name, description, code, ects_points, study_program_id)
VALUES
    (1, 'Introduction to Programming', 'Learn basic programming concepts.', 'CS101', 6, 1),
    (2, 'Data Structures', 'Study of data organization and algorithms.', 'CS102', 6, 1);

INSERT INTO syllabuses (id, course_id, content, academic_year)
VALUES
    (1, 1, 'Introduction to Java, variables, loops, functions.', '2025-2026'),
    (2, 2, 'Arrays, linked lists, trees, sorting algorithms.', '2025-2026');
INSERT INTO users (id, username, email, first_name, last_name, index_number, role, password)
VALUES (4, 'student3', 'student2@example.com', 'Jane2', 'Doe2', '678912', 'STUDENT', 'password');
INSERT INTO courses (id, name, description, code, ects_points, study_program_id)
VALUES (3, 'Data Structures2', 'Study of data organization and algorithms2.', 'CS103', 6, 2); 
INSERT INTO exam_applications (id, user_id, course_id, term)
VALUES (1, 3, 1, 'Fall 2025');
INSERT INTO exam_grades (id, exam_application_id, grade, number_of_taken_exams)
VALUES (1, 1, 8.5, 1);

