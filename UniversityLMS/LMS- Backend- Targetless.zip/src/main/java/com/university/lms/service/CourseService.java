package com.university.lms.service;

import com.university.lms.entity.Course;
import com.university.lms.entity.Syllabus;
import com.university.lms.repository.CourseRepository;
import com.university.lms.repository.SyllabusRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CourseService {

    private static final Logger logger = LoggerFactory.getLogger(CourseService.class);

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private SyllabusRepository syllabusRepository;   

    public CourseService(CourseRepository courseRepository) {
        this.courseRepository = courseRepository;
    }

    public List<Course> findAll() {
        logger.info("Fetching all courses");
        return courseRepository.findAll();
    }

    public Optional<Course> findById(Long id) {
        logger.info("Fetching course with id: {}", id);
        return courseRepository.findById(id);
    }

    public Syllabus getSyllabus(Long courseId) {
        logger.info("Fetching syllabus for course id: {}", courseId);
        return syllabusRepository.findByCourseId(courseId)
                .orElseThrow(() -> new IllegalArgumentException("Syllabus not found for course: " + courseId));
    }

    public void setSyllabus(Long courseId, Syllabus syllabus) {
        logger.info("Setting syllabus for course id: {}", courseId);
        syllabus.setCourseId(courseId);
        syllabusRepository.save(syllabus);
    }
    
    public List<Course> getCoursesByStudyProgram(Long studyProgramId) {
        return courseRepository.findByStudyProgramId(studyProgramId);
    }

    public Course createCourse(Course course) {
        course.setId(null); 
        return courseRepository.save(course);
    }

    public Course updateCourse(Long id, Course course) {
        course.setId(id);
        return courseRepository.save(course);
    }

    public void deleteCourse(Long id) {
        courseRepository.deleteById(id);
    }
    
    public boolean existsById(Long id) {
        return courseRepository.existsById(id);
    }
}