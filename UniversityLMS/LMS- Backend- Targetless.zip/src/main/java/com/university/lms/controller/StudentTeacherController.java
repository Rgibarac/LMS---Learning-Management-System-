package com.university.lms.controller;

import com.university.lms.dto.*;
import com.university.lms.entity.*;
import com.university.lms.service.ExamApplicationService;
import com.university.lms.service.ExamGradeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/student-teacher")
public class StudentTeacherController {
    @Autowired
    private ExamApplicationService examApplicationService;
    @Autowired
    private ExamGradeService examGradeService;

    private ExamApplicationResponseDTO toExamApplicationResponseDTO(ExamApplication examApplication) {
        UserDTO userDTO = new UserDTO(
            examApplication.getUser().getId(),
            examApplication.getUser().getUsername(),
            examApplication.getUser().getEmail(),
            examApplication.getUser().getFirstName(),
            examApplication.getUser().getLastName(),
            examApplication.getUser().getIndexNumber(),
            examApplication.getUser().getRole()
        );
        CourseDTO courseDTO = new CourseDTO(
            examApplication.getCourse().getId(),
            examApplication.getCourse().getName(),
            examApplication.getCourse().getDescription(),
            examApplication.getCourse().getCode(),
            examApplication.getCourse().getEctsPoints(),
            examApplication.getCourse().getStudyProgramId()
        );
        return new ExamApplicationResponseDTO(
            examApplication.getId(), userDTO, courseDTO, examApplication.getTerm()
        );
    }

    private ExamGradeResponseDTO toExamGradeResponseDTO(ExamGrade examGrade) {
        return new ExamGradeResponseDTO(
            examGrade.getId(),
            toExamApplicationResponseDTO(examGrade.getExamApplication()),
            examGrade.getGrade(),
            examGrade.getNumberOfTakenExams()
        );
    }

    @PostMapping("/exam-applications")
    public ResponseEntity<ExamApplicationResponseDTO> createExamApplication(@RequestBody ExamApplicationRequestDTO request) {
        try {
            ExamApplication examApplication = examApplicationService.createExamApplication(
                request.getUserId(), request.getCourseId(), request.getTerm());
            return ResponseEntity.status(201).body(toExamApplicationResponseDTO(examApplication));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @GetMapping("/exam-applications/user/{userId}")
    public ResponseEntity<List<ExamApplicationResponseDTO>> getExamApplicationsByUserId(@PathVariable Long userId) {
        try {
            List<ExamApplicationResponseDTO> applications = examApplicationService.getExamApplicationsByUserId(userId)
                .stream()
                .map(this::toExamApplicationResponseDTO)
                .collect(Collectors.toList());
            return ResponseEntity.ok(applications);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @GetMapping("/exam-applications")
    public ResponseEntity<List<ExamApplicationResponseDTO>> getAllExamApplications() {
        List<ExamApplicationResponseDTO> applications = examApplicationService.getAllExamApplications()
            .stream()
            .map(this::toExamApplicationResponseDTO)
            .collect(Collectors.toList());
        return ResponseEntity.ok(applications);
    }

    @DeleteMapping("/exam-applications/{id}")
    public ResponseEntity<Void> deleteExamApplication(@PathVariable Long id) {
        try {
            examApplicationService.deleteExamApplication(id);
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @PostMapping("/exam-grades")
    public ResponseEntity<ExamGradeResponseDTO> createExamGrade(@RequestBody ExamGradeRequestDTO request) {
        try {
            ExamGrade examGrade = examGradeService.createExamGrade(
                request.getExamApplicationId(), request.getGrade(), request.getNumberOfTakenExams());
            return ResponseEntity.status(201).body(toExamGradeResponseDTO(examGrade));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @GetMapping("/exam-grades/application/{examApplicationId}")
    public ResponseEntity<List<ExamGradeResponseDTO>> getExamGradesByExamApplicationId(@PathVariable Long examApplicationId) {
        try {
            List<ExamGradeResponseDTO> grades = examGradeService.getExamGradesByExamApplicationId(examApplicationId)
                .stream()
                .map(this::toExamGradeResponseDTO)
                .collect(Collectors.toList());
            return ResponseEntity.ok(grades);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @GetMapping("/exam-grades")
    public ResponseEntity<List<ExamGradeResponseDTO>> getAllExamGrades() {
        List<ExamGradeResponseDTO> grades = examGradeService.getAllExamGrades()
            .stream()
            .map(this::toExamGradeResponseDTO)
            .collect(Collectors.toList());
        return ResponseEntity.ok(grades);
    }

    @DeleteMapping("/exam-grades/{id}")
    public ResponseEntity<Void> deleteExamGrade(@PathVariable Long id) {
        try {
            examGradeService.deleteExamGrade(id);
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        }
    }
}