package com.university.lms.service;

import com.university.lms.entity.Enrollment;
import com.university.lms.repository.EnrollmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EnrollmentService {
    @Autowired
    private EnrollmentRepository enrollmentRepository;

    public List<Enrollment> findByStudentId(Long studentId) {
        return enrollmentRepository.findByStudentId(studentId);
    }

    public Enrollment saveCourseEnrollment(Long studentId, Long courseId) {
        boolean alreadyEnrolled = enrollmentRepository.findByStudentId(studentId)
            .stream()
            .anyMatch(e -> e.getCourseId() != null && e.getCourseId().equals(courseId));
        if (!alreadyEnrolled) {
            Enrollment enrollment = new Enrollment(studentId, courseId, null);
            return enrollmentRepository.save(enrollment);
        }
        return null;
    }

    public Enrollment saveStudyProgramEnrollment(Long studentId, Long studyProgramId) {
        boolean hasStudyProgram = enrollmentRepository.findByStudentId(studentId)
            .stream()
            .anyMatch(e -> e.getStudyProgramId() != null);
        if (!hasStudyProgram) {
            Enrollment enrollment = new Enrollment(studentId, null, studyProgramId);
            return enrollmentRepository.save(enrollment);
        }
        return null;
    }
}