package com.university.lms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

@SpringBootTest
@ContextConfiguration(classes = UniversityLmsApplication.class)
class UniversityLmsApplicationTests {

    @Test
    void contextLoads() {
        // Basic test to verify application context loads
    }
}